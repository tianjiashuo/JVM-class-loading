package test;

public class asmT {
}
