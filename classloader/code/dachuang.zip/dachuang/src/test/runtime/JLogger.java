package test.runtime;

public class JLogger {
    public static void logFileAccess(String className,String methodName,String opcode,String fileName,int lineNumber){
        System.out.println("logFileAccess");
    }
}
